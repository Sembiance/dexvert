

  ============================================== 

          GRAPHIC WORKSHOP PROFESSIONAL 

                  Version: 2.0a 
            Updated to Patch Level 12
                 August 12, 1999
            For Windows 95/98/2000/NT 

  http://www.mindworkshop.com/alchemy/gwspro.html 



              ALCHEMY MINDWORKS INC. 
              ----------------------
 http://www.mindworkshop.com/alchemy/alchemy.html 
             alchemy@mindworkshop.com 
  ______________________________________________ 
  ============================================== 



--------------------------------------------- 

  TO REGISTER GRAPHIC WORKSHOP PROFESSIONAL 
_____________________________________________ 
============================================= 
Graphic Workshop Professional and all its ancillary 
applications are shareware. We invite you to evaluate the 
Graphic Workshop Professional package to see if it's 
suitable for your needs. If you like it, please register it. 
If it turns out not to be what you need, or if you don't 
feel it's worth registering, please delete it from your hard 
drive and accept our thanks for trying it out. If you do 
productive work of any sort with this software, you are no 
longer evaluating it.

The registration for Graphic Workshop Professional is $40. 
If you have a registered copy of Graphic Workshop Classic, 
the upgrade fee is $20. Add $5.00 shipping if you'd like the 
current version sent to you on CD-ROM.

After installing Graphic Workshop Professional, check out 
the Regist.doc file in the \GraphicWorkshopProfessional 
folder for information on the many options available to 
register, or order the program on CD-ROM, by phone, fax, 
mail or via our on-line secure server. 

The unregistered evaluation copy of the most recent release of 
Graphic Workshop Professional may be distributed freely in its 
unaltered state as long as the means of distribution are in 
keeping with Alchemy Mindworks' current policies for shareware 
distribution. The current policies are summarized in the 
Sharewar.doc file which is added to the program's folder 
during installation of the program. 



----------------------- 

  ABOUT THIS DOWNLOAD 
_______________________ 
======================= 

This download contains 3 files, 

-- readme.txt  - which you obviously have found, 

-- file_id.diz - a brief description text file, and

-- gwsp20.exe  - the application install program which is: 
                 -- version 2.0a updated to patch 12 
                 -- for Windows 95/98/2000 and NT 
                 -- 6,008,832 bytes in length. 

New functionality is added to Graphic Workshop Professional 
from time to time. So it is recommended that you visit the 
program's information page, on occasion, to see if there is 
an update. The Graphic Workshop Professional's information 
page is http://www.mindworkshop.com/alchemy/gwspro.html. 

The Alchemy Mindworks CRC for gwsp20.exe is A7 23 D1 24

A CRC value can be used to check the integrity of a file 
you have downloaded. By assuring that the CRC check value 
shown here matches the CRC check value for the file in 
question, you will reduce the possibility of attempting 
to install a damaged archive to about one in 4,294,964,296 
-- odds even longer than those of winning most state-run 
lotteries. 

You must have the Alchemy Mindworks CRC software installed 
on your system to perform this check. Please visit our CRC 
page to download the CRC software if you do not currently 
have it. It's small, free and a valuable asset to make 
sure that your Alchemy Mindworks software has not been 
damaged in transit.



-------------------------------

  INSTALLATION CONSIDERATIONS
_______________________________
===============================

Graphic Workshop Professional requires a Pentium or better 
processor. A display adapter and a Windows screen driver 
capable of displaying more than 256 colours are recommended. 

Graphic Workshop Professional is the image management 
package for Windows 95, Windows 98 and Windows NT. It 
features multiple browser windows, batch processing, drag 
and drop, thumbnails, Pentium-optimized functionality and 
a lot more. If you are looking for a program to browse your 
image collection and view pictures, convert between formats, 
print your graphics as hard copy, maintain a sophisticated 
keyword database, drive a scanner, decode pictures from the 
Internet, process and fine tune your photographs, then 
Graphic Workshop Professional is the program you need.

If you need a less extensive version of Graphic Workshop, 
check out http://www.mindworkshop.com/alchemy/gww.html 
the program information page for Graphic Workshop Classic; 
the 32 bit version for Windows 95/98 and Windows NT, or 
the 16 bit version for Windows 3.1 and 3.11.



------------------------------------------------- 
 
  GRAPHIC WORKSHOP PROFESSIONAL'S FUNCTIONALITY 
_________________________________________________ 
================================================= 

The list of Graphic Workshop Professional's functionality can 
run for pages. Here are a few:

  - Convert between image formats. 
  - View files in any of the supported file formats. 
  - Create Kodak Photo-CD image files. 
  - Play MP3, WAV, MIDI, AVI, MPEG... files. 
  - Display a slide show of images. 
  - Print image files to any printer supported by Windows. 
  - Reverse image files. 
  - Dither colour images into halftones. 
  - Rotate image files in any increments. 
  - Flip image files vertically and horizontally. 
  - Scale images up or down with optional anti-aliased scaling. 
  - Colour reduce and colour dither images. 
  - Soften, sharpen and manipulate colour images. 
  - Adjust image colour, contrast and brightness. 
  - Crop images interactively. 
  - Move and copy files. 
  - Apply sophisticated image filters to your graphics, 
    including soften, sharpen, emboss and edge detection. 
  - Maintain an image database with keyword searching. 
  - Run any function in batch mode. 
  - Use virtual memory to work with large images. 
  - Analyse unknown graphic files 
  - Print high-resolution paper catalogs of your picture collection 
  - Create Windows icons. 
  - Display and extract frames from animations. 
  - Create thumbnail arrays of your image collection. 
  - Acquire images from a TWAIN scanner. 
  - Add text captions to your graphics. 
  - Identify mystery graphic files. 
  - Create animated screen savers from your graphics. 
  - View and convert downloadable and on-disk photographs from 
    many commercial photofinishers, including Wolf Camera, 
    Konica, The Camera Shop, Mystic Color Lab, Snap Shops, 
    Blacks, Ritz Camera and York Link.* 

    *These names are registered trademarks of the 
     businesses listed. None of these photofinishers 
     are affiliated with Alchemy Mindworks Inc. 


In addition to the Graphic Workshop Professional software itself, 
the Graphic Workshop Professional suite includes several ancillary 
applications. Registering Graphic Workshop Professional also 
registers these applications. Shareware versions of this software 
are included with the Graphic Workshop Professional downloadable 
installer. 

-- GIF Construction Set UltraLight 
   A simplified version of Alchemy Mindworks' popular GIF animator. 
   Create instant web page animations using the built-in Animation 
   Wizard. 

-- Camera Screen Capture 
   Capture all or part of a Windows screen to image files (Windows 
   95 and 98 only). 

-- Rotator 
   Have your Windows wallpaper or your screen savers automatically 
   changed each morning. 

-- Resource Extractor 
   Easily locate and extract icons, bitmaps, sounds and other 
   resources from Windows executables and DLL libraries. 


Graphic Workshop Professional supports these formats: 

  Adobe Photoshop PSD  
  AOL/Johnson-Grace ART  
  AVI Video for Windows  
  BGA OS/2 graphic arrays  
  Casio digital camera CAM  
  CompuServe GIF (with animated GIF viewing)  
  Corel CDR preview and bitmaps  
  Digital Research/Ventura IMG  
  DCX FAX files  
  EXE self-displaying pictures  
  FITS  
  FlashPix  
  FLI/FLC animation files  
  Halo CUT  
  HAM -- Amiga hold and modify  
  ICO Windows icon files  
  IFF/LBM  
  Iterated Systems FIF  
  JFIF JPEG files  
  Kodak Digital Science Camera KDC  
  Kodak Photo-CD PCD  
  MacPaint  
  Microsoft Paint MSP  
  MIDI music files (play only)  
  MPEG viewing  
  PC Paintbrush PCX  
  Pegasus PIC files  
  PFS:First Publisher ART files  
  PIC (as used by GLpro/GLpaint)  
  PICT -- Macintosh metafile  
  PNG Portable Network Graphics  
  QuickTime MOV  
  Seattle Film Works SFW files  
  Silicon Graphics workstation SGI  
  Slow scan television HRZ files  
  Sun Raster RAS files  
  Targa Truevision  
  Text files  
  TIFF  
  TTF TrueType font preview  
  UUE encoded graphics  
  Windows BMP, DIB and RLE  
  Windows metafiles (WMF)  
  Windows screen savers (SCR)  
  Windows WAV files (play only)  
  WordPerfect Graphics WPG  
  XBM  



-------------------------------------------------

  INSTALLATION OF GRAPHIC WORKSHOP PROFESSIONAL 
_________________________________________________
=================================================

Extract the file gwsp20.exe from this zipped file to a temporary 
folder such as c:\temp

Please install Graphic Workshop Professional through the 
Run item of your Start menu. It is recommended that you close 
all applications before installing. Installing it through 
Explorer or Add/Remove Programs will usually fail very colourfully. 

The steps to follow are

-- On your taskbar, click on start, then on run

-- Click on browse, then select the temporary folder you specified
   when extracting gwsp20.exe 

-- Click once on the file gwsp20.exe and then on Open, or double 
   click the file gwsp20.exe, to display the program in the Open 
   window of the Run screen 

-- Click OK to start the self-extracting Windows archive to install 
   GIF Construction Set Professional. 

-- follow the prompts that guide you through the install procedure 

-- after installation, the source file gwsp20.exe can be deleted 
   from the temporary folder.  

You must have a minimum of 16 megabytes of free hard drive space to 
install this package. Part of this space is used for temporary files 
created by the installer, and will be freed as soon as the 
installation is complete. 



----------------------------------------------

  TO UNINSTALL GRAPHIC WORKSHOP PROFESSIONAL
______________________________________________
==============================================

Use Add or Remove Programs -- The steps to follow are:

-- On your taskbar, click on start, then higligh Settings, then 
   click on Control Panel in the option list displayed

-- Double click the Add/Remove Programs icon  

-- Make sure the Install/Uninstall tab is selected, scroll through 
   the list of installed applications to locate Graphic Workshop 
   Professional, and click once on it.

-- Click the Add/Remove button to display the information about
   Graphic Workshop Professional and click on the Uninstall button
   if this is the program that you really want to uninstall. 



  ========================
   ALCHEMY MINDWORKS Inc.
  Since the earth was flat

    www.mindworkshop.com
         Creator of

      GRAPHIC WORKSHOP 
    GIF CONSTRUCTION SET  
       FONT WRANGLER 
      PAGAN DAYBOOK II 
    --------------------
         plus other 
    innovative shareware
        applications
  ________________________
  ========================

