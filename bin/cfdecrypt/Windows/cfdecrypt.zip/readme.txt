CFDECRYPT for Allaire ColdFusion
--------------------------------

cfdecrypt.exe is a Windows binary of the CFDECRYPT program posted to BugTraq, which
decrypts encrypted ColdFusion templates.

Source (cfdecrypt.c) and MS Visual Studio project file (cfdecrypt.dsp) are also provided.
You need libdes if you want to compile it yourself.

Matt Chapman <matthewc@cse.unsw.edu.au>
27th July 1999
