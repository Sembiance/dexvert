Copy the enclosed files into the same directory:

C:\Program Files\Common Files\Microsoft Shared\TextConv

and merge the registry file with your registry.

This filter may produce a security warning when used.

This does not work with Windows 7 64 bit. If you need details for that version, please contact me via the link on the home page of my web site. www.gmayor.com 